// assets/admin.js – logika wykresów i filtrów
jQuery(document).ready(function ($) {
    console.log('SF Dashboard + Chart.js loaded');

    // Opcjonalne: Dodaj filtr po dacie (AJAX)
    // $('#filter-date').on('change', function() { /* AJAX do sf_filter_stats */ });
});